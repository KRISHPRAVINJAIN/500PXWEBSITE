export class PhotoVotes {
    id: number;
    fullname: string;
    userpic_https_url: string;
    userpic_url: string;
}