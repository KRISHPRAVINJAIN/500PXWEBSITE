import { UserDetails } from "./UserDetails";

export class comments {
    body: string;
    created_at: Date;
    user: UserDetails;
}