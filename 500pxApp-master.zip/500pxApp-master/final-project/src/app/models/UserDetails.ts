export class UserDetails {
    id: number;
    userpic_url: string;
    username: string;
    lastname: string;
    firstname: string;
    fullname: string;
    friends_count: number;
    followers_count: number;
}