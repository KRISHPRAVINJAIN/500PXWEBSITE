export class Images {
    format: string;
    https_url: string;
    size: number;
    url: string;
}