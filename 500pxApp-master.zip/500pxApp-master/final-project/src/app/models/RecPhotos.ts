import { Photo } from './Photo';

export const PHOTOS: Photo[] = []; 