var settings = {
    consumerkey: 'ycVhYsDeMblD3bPN8sFzKPLBfK3yrfZvn7qPsGf5',
    consumersecret: 'F5u9TPwDNHSMdbvmN745uxLBiCYD8Cd8q7VTqqTX',
    jsSDKKey: '1d1b05c6cd11ac847432230194d953ae80a100fd',
    accessToken: '',
}

module.exports = settings;
