### DEPRECATED

Please use the corresponding **[galleries endpoint][]**

***

# Collections Resources

    DELETE collections/:collection_id

## Description
Deletes collection.

***

## Requires authentication
**[OAuth][]**

***

## Return format
**TODO**

***

## Errors
None

***

## Example
**Request**

    GET v1/collections

**Return**

**TODO**

[OAuth]: https://github.com/500px/api-documentation/tree/master/authentication
[Feature]: https://github.com/500px/api-documentation/blob/master/basics/formats_and_terms.md#500px-photo-terms
[short format]: https://github.com/500px/api-documentation/blob/master/basics/formats_and_terms.md#short-format-1
[galleries endpoint]: https://github.com/500px/api-documentation/blob/master/endpoints/galleries/DELETE_galleries_id.md
