# Photo Resources

    GET example/:id

## Description

***

## Requires authentication

***

## Parameters

***

## Return format

***

## Errors

***

## Example
**Request**

    Code Example

**Return**

    Code Example


[photo stream]: https://github.com/500px/api-documentation/blob/master/basics/formats_and_terms.md#500px-photo-terms
[OAuth]: https://github.com/500px/api-documentation/tree/master/authentication
[full format]: https://github.com/500px/api-documentation/blob/master/basics/formats_and_terms.md#full-format
[short format]: https://github.com/500px/api-documentation/blob/master/basics/formats_and_terms.md#short-format-1
[category]: https://github.com/500px/api-documentation/blob/master/basics/formats_and_terms.md#categories